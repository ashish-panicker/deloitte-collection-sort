package com.example.demo.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootDemoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
