package com.example.boot.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
